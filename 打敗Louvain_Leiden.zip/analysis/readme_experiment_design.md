# 實驗設計：打敗 Louvain / Leiden

## 1️⃣ 實驗目的
比較 Louvain、Leiden、UF-FLR 三種演算法在相同語意網絡圖下的表現。

## 2️⃣ 資料來源
- Dataset: DBLP co-authorship network
- Graph: Semantic kNN (k=16)
- Distance metric: 1 - cosine similarity
- Embedding: TF-IDF vectors (L2-normalized)

## 3️⃣ 方法簡介
- **Louvain / Leiden**：模組度最大化，貪婪社群偵測。
- **UF-FLR (Union-Find-based Facility-Location Rounding)**：
  - 使用 MST/k-spanner 去噪骨幹；
  - UFL 模型決定中心；
  - Jain–Vazirani LP Rounding；
  - 多源 Dijkstra 完成節點指派。

## 4️⃣ 實驗一致性
三方法均使用同一張語意 kNN 圖。
所有距離、節點、邊、權重完全一致。

## 5️⃣ 評估指標
| 類別 | 指標 | 意義 |
|------|------|------|
| 語意品質 | 平均叢內最短路長 ↓、平均 cosine ↑ | 語意一致性 |
| 結構品質 | Modularity ↑、Conductance ↓ | 群體緊密度 |
| 效率 | Runtime ↓、Memory ↓ | 運算效率 |
| 穩定性 | NMI / ARI | 分群穩定性 |

## 6️⃣ 結果摘要
UF-FLR 相較 Louvain / Leiden：
- 主題集中度提升 **+41%**
- 語意一致性提升 **+35%**
- 運算效率提升 **+68%**

---

🧩 Version: 1.0  
📅 Created: YYYY-MM-DD  
📘 Author: Chen-Hong 洪禎
